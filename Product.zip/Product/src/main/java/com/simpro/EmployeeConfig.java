package com.simpro;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.simpro.Employee;

//@Configuration
public class EmployeeConfig {

	/*@Bean(name="employee")
	public Employee employee() {
		return new Employee("kavi",101);
	}*/
}
