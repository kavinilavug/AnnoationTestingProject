package com.simpro;

public class AppConfig {

}
